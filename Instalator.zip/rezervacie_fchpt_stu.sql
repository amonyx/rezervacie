-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 13, 2015 at 11:29 PM
-- Server version: 5.6.15
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `rezervacie fchpt stu`
--
CREATE DATABASE IF NOT EXISTS `rezervacie fchpt stu` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `rezervacie fchpt stu`;

-- --------------------------------------------------------

--
-- Table structure for table `logy`
--

CREATE TABLE IF NOT EXISTS `logy` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Uzivatel` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Akcia` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Datum` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Popis` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `mapa_rezervacie`
--

CREATE TABLE IF NOT EXISTS `mapa_rezervacie` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ID_Rezervacia` int(11) NOT NULL,
  `Zaciatok` datetime NOT NULL,
  `Koniec` datetime NOT NULL,
  `Pocet_Osob` int(3) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `miestnost`
--

CREATE TABLE IF NOT EXISTS `miestnost` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Kapacita` int(3) NOT NULL,
  `Nazov` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ID_Typ_Miestnosti` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `rezervacia`
--

CREATE TABLE IF NOT EXISTS `rezervacia` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ID_Uzivatel` int(11) NOT NULL,
  `ID_Miestnost` int(11) NOT NULL,
  `Ucel` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `typy_miestnosti`
--

CREATE TABLE IF NOT EXISTS `typy_miestnosti` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Nazov` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `uzivatel`
--

CREATE TABLE IF NOT EXISTS `uzivatel` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Meno` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Priezvisko` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Login` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Heslo` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `Admin` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `uzivatel`
--

INSERT INTO `uzivatel` (`ID`, `Meno`, `Priezvisko`, `Login`, `Heslo`, `Admin`) VALUES
(1, 'Admin', 'Admin', 'admin', 'e52b72d3da8021318ac53564b542dbf2c321a50e', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
