<?php
 
/** Configuration Variables **/
define('URL_BASE', 'Rezervacie_FCHPT_STU');
define('DOMAIN', 'localhost');

define('DB_NAME', 'rezervacie fchpt stu');//
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');
?>